package com.examplewd.oczkower2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.Random;


public class MainActivity extends AppCompatActivity {

    private Button nastepnaKarta, koniecGry,NowaGra;
    private ImageView losowaKarta,losowaKarta2;
    private TextView dane,dane2;

    private listyKart wszystkieKarty = new listyKart();
    private int[][] listaKart = wszystkieKarty.getKartyRodzaje();
    private Random random1= new Random();
    private Random random2= new Random();
    private Random random3= new Random();
    private Random random4= new Random();

    private static int[] punktyLista = {
            2,
            3,
            4,
            5,
            6,
            7,
            8,
            9,
            10,
            2,
            3,
            4,
            11
    };

    int[] mojeKarty = new int[10];
    int[] krupierKarty = new int[10];
    int punkty = 0;
    int ileKart = 0;
    int punktyK =0;
    int IleKartK =0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nastepnaKarta = findViewById(R.id.b1);
        koniecGry = findViewById(R.id.b2);
        losowaKarta = findViewById(R.id.imgS1);
        losowaKarta2=findViewById(R.id.ImgS2);
        dane = findViewById(R.id.W1);
        dane2=findViewById(R.id.W2);
        NowaGra=findViewById(R.id.b3);


        nastepnaKarta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                losujKarte();
                losujKarteKupier();
            }
        });

        koniecGry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dane.setText("Twoje punkty: " + punkty);
                nastepnaKarta.setEnabled(false);
                dane2.setText("Punkty Krupiera:"+ punktyK);
                nastepnaKarta.setEnabled(false);

            }
        });
        NowaGra.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });


    }

    public void losujKarte(){
        int numer = random1.nextInt(13);
        int rodzaj = random2.nextInt(4);

        losowaKarta.setImageResource(listaKart[numer][rodzaj]);

        mojeKarty[ileKart] = punktyLista[numer];

        punkty += punktyLista[numer];
        dane.setText(punkty+"");
        ileKart++;
        if(punkty < 21){

            dane.setText(punkty + "");
        }else if(punkty == 21){
            dane.setText("WYGRANA" + " twoje punkty: " + punkty);
        }else if(punkty > 21){
            if(punkty == 22){
                if(mojeKarty.length == 2){
                    dane.setText("WYGRANA" + " Pawie oczko");
                }else{
                    dane.setText("PRZEGRANA   " + punkty);
                    nastepnaKarta.setEnabled(false);
                }
            }else{
                dane.setText("PRZEGRANA   " + punkty);
                nastepnaKarta.setEnabled(false);
            }
        }

    }
    public void losujKarteKupier(){
        int numer = random3.nextInt(13);
        int rodzaj = random4.nextInt(4);
        losowaKarta2.setImageResource(listaKart[numer][rodzaj]);
        krupierKarty[ileKart]=punktyLista[numer];
        punktyK += punktyLista[numer];
        dane2.setText(punkty+"");
        ileKart++;
        if(punktyK < 21){

            dane2.setText(punktyK + "");
        }else if(punktyK == 21){
            dane2.setText("WYGRANA" + " twoje punkty: " + punktyK);
        }else if(punktyK > 21){
            if(punktyK == 22){
                if(mojeKarty.length == 2){
                    dane2.setText("WYGRANA" + " Pawie oczko");
                }else{
                    dane2.setText("PRZEGRANA   " + punktyK);
                    nastepnaKarta.setEnabled(false);
                }
            }else{
                dane2.setText("PRZEGRANA   " + punktyK);
                nastepnaKarta.setEnabled(false);
            }
        }
    }




}
